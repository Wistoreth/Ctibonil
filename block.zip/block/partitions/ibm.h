int ibm_partition(struct parsed_partitions *);
