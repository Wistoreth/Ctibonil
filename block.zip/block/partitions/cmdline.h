
int cmdline_partition(struct parsed_partitions *state);
